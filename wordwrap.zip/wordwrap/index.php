<!DOCTYPE html>
<html>
<head>
    <title>Template Editor</title>
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    
</head>
<body>

    <label><b>select the template</b></label>
    <select id="templateSelector"></select>

    <div>
        <div id="editor" contenteditable="true"></div>
    </div>

    <div class="controls">
        <button onclick="saveTemplate()">Save</button>
        <button onclick="toggleWordWrap()">Enable/Disable Word Wrap</button>
    </div>

    <div>
        <div id="preview"></div>
    </div>

</body>
<script src="assets/js/template.js"></script>
</html>