let currentTemplate = '';
let data = {};

// Load placeholder data
fetch('data.json').then(res => res.json()).then(json => data = json);

// Load template list
fetch('get_template_lists.php')
    .then(res => res.json())
    .then(templates => {
        const selector = document.getElementById('templateSelector');
        templates.forEach(tpl => {
            const opt = document.createElement('option');
            opt.value = tpl;
            opt.innerText = tpl;
            selector.appendChild(opt);
        });

        // Auto load first
        if (templates.length > 0) {
            selector.value = templates[0];
            loadTemplate(templates[0]);
        }

        selector.addEventListener('change', e => loadTemplate(e.target.value));
    });

// Load selected template file
function loadTemplate(filename) {
    fetch('load_template.php?template=' + encodeURIComponent(filename))
        .then(res => res.text())
        .then(html => {
            currentTemplate = filename;
            document.getElementById('editor').innerHTML = html;
            updatePreview();
        });
}

// Replace placeholders
function renderWithData(html) {
    return html.replace(/\$\{(.*?)\}/g, (_, key) => data[key] || '');
}

// Update preview in real time
document.getElementById('editor').addEventListener('input', updatePreview);
function updatePreview() {
    const html = document.getElementById('editor').innerHTML;
    document.getElementById('preview').innerHTML = renderWithData(html);
}

// Save to file
function saveTemplate() {
    const content = document.getElementById('editor').innerHTML;
    fetch('save_template.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `filename=${encodeURIComponent(currentTemplate)}&content=${encodeURIComponent(content)}`
    }).then(res => res.text()).then(alert);
}

// Word wrap toggle for selected preview text
function toggleWordWrap() {
    const sel = window.getSelection();
    if (!sel.rangeCount) return;
    const range = sel.getRangeAt(0);

    const span = document.createElement('span');
    const parent = sel.anchorNode.parentElement;

    const isWrapped = parent.classList.contains('wrap-enabled');

    span.className = isWrapped ? 'wrap-disabled' : 'wrap-enabled';
    span.appendChild(range.extractContents());
    range.insertNode(span);
}
